<script setup>
import { ref, reactive, computed, onMounted } from 'vue'

// Ganti dengan URL Web App dari Google Apps Script kamu
const ENDPOINT = import.meta.env.VITE_SHEETS_ENDPOINT

const EVENT = {
  date: 'September 9, 2026',
  time: '5 PM – 8 PM',
  venue: 'Pulse Powerhub',
  address: 'Jl. Pemelisan Agung, Pantai Berawa, Tibubeneng, Canggu, Bali',
  start: new Date('2026-09-09T17:00:00+08:00')
}

const form = reactive({
  name: '',
  phone: '',
  email: '',
  guests: '1',
  member: '',
  source: 'direct'
})

const errors = reactive({})
const status = ref('idle') // idle | sending | done | error
const errorMessage = ref('')
const revealed = ref(false)

const daysLeft = computed(() => {
  const diff = EVENT.start - new Date()
  return Math.max(0, Math.ceil(diff / 86400000))
})

const calendarUrl = computed(() => {
  const params = new URLSearchParams({
    action: 'TEMPLATE',
    text: 'Pulse Powerhub Turns 1',
    dates: '20260909T090000Z/20260909T120000Z',
    location: EVENT.address,
    details: 'One year of fitness, wellness and community. Stronger together.'
  })
  return `https://calendar.google.com/calendar/render?${params}`
})

onMounted(() => {
  const params = new URLSearchParams(window.location.search)
  form.source = params.get('src') || 'direct'
  requestAnimationFrame(() => { revealed.value = true })
})

function validate () {
  Object.keys(errors).forEach(k => delete errors[k])

  if (form.name.trim().length < 2) {
    errors.name = 'Enter your full name.'
  }

  const digits = form.phone.replace(/\D/g, '')
  if (digits.length < 8) {
    errors.phone = 'Enter a valid WhatsApp number.'
  }

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim())) {
    errors.email = 'Enter a valid email address.'
  }

  if (!form.member) {
    errors.member = 'Pick one.'
  }

  return Object.keys(errors).length === 0
}

async function submit () {
  if (status.value === 'sending') return
  if (!validate()) return

  status.value = 'sending'
  errorMessage.value = ''

  const payload = {
    name: form.name.trim(),
    phone: form.phone.trim(),
    email: form.email.trim().toLowerCase(),
    guests: Number(form.guests),
    member: form.member,
    source: form.source,
    userAgent: navigator.userAgent
  }

  try {
    const res = await fetch(ENDPOINT, {
      method: 'POST',
      // text/plain menghindari CORS preflight — Apps Script tidak handle OPTIONS
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(payload)
    })

    const data = await res.json()
    if (data.status !== 'success') throw new Error(data.message || 'Save failed')

    status.value = 'done'
  } catch (err) {
    status.value = 'error'
    errorMessage.value = 'We could not save your RSVP. Check your connection and try again.'
  }
}

function retry () {
  status.value = 'idle'
  errorMessage.value = ''
}
</script>

<template>
  <div class="page" :class="{ 'is-revealed': revealed }">

    <header class="hero">
      <p class="brand">PULSE<span class="brand-sub">POWERHUB</span></p>

      <h1 class="display">
        <span class="display-line">PULSE</span>
        <span class="display-line">TURNS <em class="one">1</em></span>
      </h1>

      <p class="tagline">Stronger together</p>

      <p class="lede">
        One year of fitness, wellness and community in Berawa.
        Join us for an evening of movement, music, food and good company.
      </p>

      <p v-if="daysLeft > 0" class="counter">{{ daysLeft }} days to go</p>
    </header>

    <section class="facts" aria-label="Event details">
      <dl>
        <div class="fact">
          <dt>Date</dt>
          <dd>{{ EVENT.date }}</dd>
        </div>
        <div class="fact">
          <dt>Time</dt>
          <dd>{{ EVENT.time }}</dd>
        </div>
        <div class="fact">
          <dt>Where</dt>
          <dd>{{ EVENT.venue }}<br><span class="addr">{{ EVENT.address }}</span></dd>
        </div>
      </dl>
    </section>

    <section class="lineup" aria-label="What's happening">
      <h2 class="section-head">What's happening</h2>
      <ul class="chips">
        <li>Fitness challenge</li>
        <li>Floating pilates</li>
        <li>Recovery &amp; sauna</li>
        <li>DJ set</li>
        <li>Food &amp; drinks</li>
        <li>Prizes</li>
        <li>Bazaar</li>
        <li>Tarot booth</li>
        <li>IV drip booth</li>
      </ul>
    </section>

    <section class="rsvp" aria-label="RSVP">
      <div class="panel">

        <template v-if="status !== 'done'">
          <h2 class="panel-head">Save your spot</h2>
          <p class="panel-note">Places are limited. We will confirm on WhatsApp.</p>

          <div class="field">
            <label for="name">Full name</label>
            <input id="name" v-model="form.name" type="text" autocomplete="name"
                   :aria-invalid="!!errors.name" @input="delete errors.name">
            <p v-if="errors.name" class="err">{{ errors.name }}</p>
          </div>

          <div class="field">
            <label for="phone">WhatsApp number</label>
            <input id="phone" v-model="form.phone" type="tel" inputmode="tel"
                   placeholder="+62 8xx xxxx xxxx" autocomplete="tel"
                   :aria-invalid="!!errors.phone" @input="delete errors.phone">
            <p v-if="errors.phone" class="err">{{ errors.phone }}</p>
          </div>

          <div class="field">
            <label for="email">Email</label>
            <input id="email" v-model="form.email" type="email" autocomplete="email"
                   :aria-invalid="!!errors.email" @input="delete errors.email">
            <p v-if="errors.email" class="err">{{ errors.email }}</p>
          </div>

          <div class="row">
            <div class="field">
              <label for="guests">People coming</label>
              <select id="guests" v-model="form.guests">
                <option value="1">Just me</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </div>

            <div class="field">
              <label for="member">Pulse member?</label>
              <select id="member" v-model="form.member"
                      :aria-invalid="!!errors.member" @change="delete errors.member">
                <option value="" disabled>Select</option>
                <option value="yes">Yes</option>
                <option value="no">Not yet</option>
              </select>
              <p v-if="errors.member" class="err">{{ errors.member }}</p>
            </div>
          </div>

          <button class="cta" type="button" :disabled="status === 'sending'" @click="submit">
            {{ status === 'sending' ? 'Saving…' : 'Confirm my RSVP' }}
          </button>

          <p v-if="status === 'error'" class="err err-block">
            {{ errorMessage }}
            <button class="link" type="button" @click="retry">Try again</button>
          </p>
        </template>

        <template v-else>
          <h2 class="panel-head">You're on the list</h2>
          <p class="panel-note">
            See you on {{ EVENT.date }} at {{ EVENT.time }}.
            We'll send the details to {{ form.email }}.
          </p>
          <a class="cta cta-link" :href="calendarUrl" target="_blank" rel="noopener">
            Add to Google Calendar
          </a>
          <a class="link link-block" href="https://maps.google.com/?q=Pulse+Powerhub+Berawa+Canggu"
             target="_blank" rel="noopener">Open in Maps</a>
        </template>

      </div>
    </section>

    <footer class="foot">
      <a href="https://instagram.com/pulsepowerhub.bali" target="_blank" rel="noopener">@pulsepowerhub.bali</a>
      <span>Jl. Pemelisan Agung, Berawa</span>
    </footer>

  </div>
</template>

<style>
@import url('https://fonts.googleapis.com/css2?family=Anton&family=Barlow:ital,wght@0,400;0,500;0,600;1,600&display=swap');

:root {
  --ink: #000000;
  --paper: #ffffff;
  --pulse: #4fdde5;
  --pulse-dim: #1e5f65;
  --muted: #8b9295;
  --danger: #ff6b5e;
}

* { box-sizing: border-box; }

html, body {
  margin: 0;
  background: var(--ink);
}

body {
  font-family: 'Barlow', system-ui, sans-serif;
  color: var(--paper);
  -webkit-font-smoothing: antialiased;
}

#app { min-height: 100vh; }
</style>

<style scoped>
.page {
  max-width: 46rem;
  margin: 0 auto;
  padding: 3rem 1.5rem 4rem;
}

/* one orchestrated entrance, nothing else moves on its own */
.hero, .facts, .lineup, .rsvp {
  opacity: 0;
  transform: translateY(12px);
  transition: opacity .5s ease, transform .5s ease;
}
.is-revealed .hero { opacity: 1; transform: none; transition-delay: .05s; }
.is-revealed .facts { opacity: 1; transform: none; transition-delay: .15s; }
.is-revealed .lineup { opacity: 1; transform: none; transition-delay: .22s; }
.is-revealed .rsvp { opacity: 1; transform: none; transition-delay: .3s; }

@media (prefers-reduced-motion: reduce) {
  .hero, .facts, .lineup, .rsvp {
    opacity: 1; transform: none; transition: none;
  }
}

/* --- hero --- */
.brand {
  font-family: 'Anton', sans-serif;
  font-size: 1.05rem;
  letter-spacing: .22em;
  margin: 0 0 3rem;
  color: var(--paper);
}
.brand-sub {
  display: block;
  font-family: 'Barlow', sans-serif;
  font-weight: 500;
  font-size: .58rem;
  letter-spacing: .5em;
  color: var(--muted);
  margin-top: .2rem;
}

.display {
  font-family: 'Anton', sans-serif;
  font-size: clamp(3.6rem, 15vw, 7rem);
  line-height: .86;
  margin: 0;
  transform: skewX(-6deg);
  transform-origin: left;
}
.display-line { display: block; }
.one {
  font-style: normal;
  color: var(--pulse);
  font-size: 1.18em;
  line-height: 0;
  margin-left: .06em;
}

.tagline {
  font-weight: 600;
  font-style: italic;
  font-size: 1.05rem;
  letter-spacing: .14em;
  color: var(--pulse);
  margin: 1.6rem 0 0;
}

.lede {
  max-width: 34ch;
  font-size: 1.02rem;
  line-height: 1.55;
  color: #d4d9da;
  margin: 1.1rem 0 0;
}

.counter {
  display: inline-block;
  margin: 1.6rem 0 0;
  font-size: .8rem;
  letter-spacing: .16em;
  color: var(--muted);
  border-bottom: 1px solid var(--pulse-dim);
  padding-bottom: .3rem;
}

/* --- facts: the neon-outlined box from the flyer --- */
.facts {
  margin: 3.2rem 0 0;
  border: 1px solid var(--pulse);
  border-radius: 14px;
  padding: 1.5rem 1.6rem;
  box-shadow: 0 0 26px rgba(79, 221, 229, .13);
}
.facts dl { margin: 0; }
.fact {
  display: grid;
  grid-template-columns: 5.5rem 1fr;
  gap: 1rem;
  padding: .75rem 0;
  border-bottom: 1px solid rgba(79, 221, 229, .18);
}
.fact:last-child { border-bottom: 0; padding-bottom: 0; }
.fact:first-child { padding-top: 0; }
.fact dt {
  font-size: .82rem;
  letter-spacing: .1em;
  color: var(--pulse);
  padding-top: .12rem;
}
.fact dd {
  margin: 0;
  font-weight: 500;
  font-size: 1.05rem;
  line-height: 1.4;
}
.addr {
  font-weight: 400;
  font-size: .88rem;
  color: var(--muted);
}

/* --- lineup --- */
.lineup { margin: 3rem 0 0; }
.section-head {
  font-family: 'Anton', sans-serif;
  font-size: 1.5rem;
  letter-spacing: .02em;
  margin: 0 0 1.1rem;
  font-weight: 400;
}
.chips {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-wrap: wrap;
  gap: .5rem;
}
.chips li {
  border: 1px solid #262b2c;
  border-radius: 999px;
  padding: .42rem .85rem;
  font-size: .88rem;
  color: #c3c9ca;
}

/* --- rsvp --- */
.rsvp { margin: 3.2rem 0 0; }
.panel {
  background: #0a0d0e;
  border: 1px solid #1b2122;
  border-radius: 16px;
  padding: 1.8rem 1.6rem 2rem;
}
.panel-head {
  font-family: 'Anton', sans-serif;
  font-size: 1.8rem;
  margin: 0;
  font-weight: 400;
}
.panel-note {
  color: var(--muted);
  font-size: .94rem;
  margin: .45rem 0 1.7rem;
  line-height: 1.5;
}

.field { margin: 0 0 1.15rem; }
.field label {
  display: block;
  font-size: .84rem;
  letter-spacing: .04em;
  color: #aeb5b6;
  margin-bottom: .42rem;
}
.field input,
.field select {
  width: 100%;
  background: #000;
  border: 1px solid #2a3132;
  border-radius: 9px;
  color: var(--paper);
  font-family: inherit;
  font-size: 1rem;
  padding: .72rem .85rem;
  transition: border-color .15s ease;
}
.field input:focus,
.field select:focus {
  outline: 2px solid var(--pulse);
  outline-offset: 2px;
  border-color: var(--pulse);
}
.field input[aria-invalid='true'],
.field select[aria-invalid='true'] { border-color: var(--danger); }

.row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1rem;
}

.err {
  color: var(--danger);
  font-size: .84rem;
  margin: .4rem 0 0;
}
.err-block { margin-top: .9rem; }

.cta {
  display: block;
  width: 100%;
  margin-top: .6rem;
  background: var(--pulse);
  color: #000;
  border: 0;
  border-radius: 9px;
  font-family: 'Anton', sans-serif;
  font-size: 1.05rem;
  letter-spacing: .06em;
  padding: .95rem 1rem;
  cursor: pointer;
  transition: filter .15s ease;
}
.cta:hover:not(:disabled) { filter: brightness(1.12); }
.cta:disabled { opacity: .55; cursor: default; }
.cta:focus-visible { outline: 2px solid var(--paper); outline-offset: 3px; }

.cta-link {
  text-align: center;
  text-decoration: none;
  margin-top: 1.4rem;
}

.link {
  background: none;
  border: 0;
  color: var(--pulse);
  font: inherit;
  text-decoration: underline;
  cursor: pointer;
  padding: 0 0 0 .35rem;
}
.link-block {
  display: block;
  text-align: center;
  margin-top: 1rem;
  padding: 0;
  font-size: .92rem;
}

/* --- footer --- */
.foot {
  margin: 3.5rem 0 0;
  padding-top: 1.4rem;
  border-top: 1px solid #1b2122;
  display: flex;
  flex-wrap: wrap;
  gap: .5rem 1.5rem;
  justify-content: space-between;
  font-size: .86rem;
  color: var(--muted);
}
.foot a { color: var(--pulse); text-decoration: none; }
.foot a:hover { text-decoration: underline; }

@media (max-width: 30rem) {
  .page { padding: 2.2rem 1.15rem 3rem; }
  .fact { grid-template-columns: 1fr; gap: .25rem; }
  .row { grid-template-columns: 1fr; gap: 0; }
}
</style>
